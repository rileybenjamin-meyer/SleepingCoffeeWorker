
#1.

def main():
    #Import random is similar to button and graphics, as it is importing seperate code,
    #so its more efficient and organized
    import random
    mylist=["Good Afternoon", "Good Evening", "Good Morning"] 
    #random.choice is calling on the imported code
    print(random.choice(mylist))
    # input is asking the user to input a string , so we can call on it
    #in the future
    x=input("What is your name?")
    print("Hello,it is nice to meet you " + x)
    print("My name is Riley")

if __name__== "__main__":
    main()

#2.

def isMultiple(num1, num2):
    if num1 % num2 == 0:
        print(str(num1) + " is a multiple of " + str(num2))
    else:
        print(str(num1) + "is not a multiple of " + str(num2))


#3.
def palindrome():
    s = input("Type in a palindrome you want to test")

    length = len(s)

    #for loop to repeat
    #i starts at 0, and it adds one each time
    for i in range(length):
        if s[i] != s[length - 1 - i]:
            return False
        
    return True
      
def p1Main():

    isMultiple(42,7)
    answer = palindrome()
    print(answer)

if __name__== "__main__":
    main()
