
#Python Problem Set 2

#1.


def factorial(x):
    y = 1

    for i in range(2, x+1):
        y = y * i
    
        
    print("The factorial is: " + str(y))


#2.

def doubleIt():
    l = input("Write a phrase you want to double: ")
    s=" "

    for i in l:
        s = s + i + i
        
    print(s)

#3.


def camelCode():

    F = input(str("Enter a potential filename:"))

    y = F.title()
        
    a = y.replace(" ", "")

    b = a.replace("/", "-")

    c = b[0].lower() + b[1:]

    print(c)




def p2Main():
    x = int(input("Write a number to find the factorial: "))
    factorial(x)

    camelCode()

    doubleIt()

if __name__ == "__main__":
    main()









