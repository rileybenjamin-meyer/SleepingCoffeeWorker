from zoo import *
from pythonImageEditor import *
from characterCreator import *
from problemSet2 import *
from pythonProblemSet1 import *
#I imported most of my past assignment into this file, so I could create buttons
#that runs each of these assignments through this file
def reset(I):
    main()

def main():
#Here I made all of the buttons

    mainWin = GraphWin("Portfolio", 860, 500)
    Q = Button(mainWin, Point(600,50), Point(700,150), "firebrick2", "QUIT")
    R = Button(mainWin, Point(710,50), Point(810,150), "sienna1", "RESET")
    I = Button(mainWin, Point(50, 50), Point(150, 150), "chartreuse3", "Image Editor")
    IB = Button(mainWin, Point(50, 160), Point(150, 450), "chartreuse3", "")
    Char = Button(mainWin, Point(160, 50), Point(260,150), "lightsalmon1", "Character Creator")
    CharB = Button(mainWin, Point(160, 160), Point(260, 450), "lightsalmon1", "")
    P1 = Button(mainWin, Point(270, 50), Point(370, 150), "deepskyblue1", "Problem Set 1")              
    P1B = Button(mainWin, Point(270, 160), Point(370, 450), "deepskyblue1", "")
    P2 = Button(mainWin, Point(380, 50), Point(480, 150), "lightslateblue", "Problem Set 2")
    P2B = Button(mainWin, Point(380, 160), Point(480, 450), "lightslateblue", "")
    Z = Button(mainWin, Point(490, 50), Point(590, 150), "paleturquoise1", "Zoo")
    Z2 = Button(mainWin, Point(490, 160), Point(590, 450), "paleturquoise1", "")
    
#Here I made text boxes where I could describe each assignment
    T1 = Text(Point(100, 250), "The goal of\nimage editor was\n to create a\n GUI that holds\n an image and\n the color can\n be manipulated\n through a ser-\nies of diff-\nerent buttons.")
    T1.draw(mainWin)

    T2 = Text(Point(210, 250), "The goal of\ncharacter creator\nwas to make\na GUI and\nbe able to\ncreate a fa-\nce through\ndifferent buttons\n associated with\n different facial\nfeatures.")
    T2.draw(mainWin)

    T3 = Text(Point(320, 300), "The goal of \nproblem set 1\nwas to solve\n three problems with\nsimple python\nfunctions, we had\ncreate a code\nthat writes a\ngreeting. The 2nd\n had to take in two\nintegers as para-\nmeters and pri-\nnt if the\n1st number is a\nmultiple of the\nsecond.The 3rd\n had to say if\n a phrase was\n a palindrome.")
    T3.draw(mainWin)

    T4 = Text(Point(430 , 285), "The goal of\nproblem set 2\nwas to create\n a code that\noutputs the\nfactorial of the\nusers input number.\nThe second problem\nhad to output\nthe doubled version\nof the users\ninput phrase.\n The 3rd problem\nwas to output\n the camel case\nversion of an\npotential filename.") 
    T4.draw(mainWin)

    T5 = Text(Point(540, 230), "The goal of\nzoo was to\npractice defining\na class using\nlists and parameters\nby making a 'zoo'\n of different\nanimals and their\nhabitats.")
    T5.draw(mainWin)

#I used a while true loop, because if it is true that a button was clicked,
#it should go through the directed steps. I changed all of the main methods
#in my imported files to different names so thta it is easier to know which main
#file if being called
    while True:
        m = mainWin.getMouse()

        if Q.isClicked(m):
            break

        if R.isClicked(m):
            reset(mainWin)

        if I.isClicked(m):
            imMain()

        if Char.isClicked(m):
            cMain()

        if P1.isClicked(m):
            p1Main()

        if P2.isClicked(m):
            p2Main()

        if Z.isClicked(m):
            zMain()
            
    mainWin.close()

if __name__ == "__main__":
    main()
    
